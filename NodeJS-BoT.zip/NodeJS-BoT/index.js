const TelegramApi = require('node-telegram-bot-api')

const  api = '5221998842:AAEVjOchYj83xmpcGSaWWr6FuT9PHWyRFX0'
const bot = new TelegramApi(api,{polling:true});
const chats = {};
const gameOptions = {
  reply_markup:JSON.stringify(
     {
       inline_keyboard:[
         [{text:'1', callback_data:'1'},{text:'2', callback_data:'2'},{text:'3', callback_data:'3'}],
         [{text:'4', callback_data:'4'},{text:'5', callback_data:'5'},{text:'6', callback_data:'6'}],
         [{text:'7', callback_data:'7'},{text:'8', callback_data:'8'},{text:'9', callback_data:'9'}],
         [{text:'0', callback_data:'0'}]
        
                
]})}
const restartOptions = {
    reply_markup:JSON.stringify(
       {
         inline_keyboard:[
           [{text:`Yana o'ynash`, callback_data:'/restart'}],
       
          
                  
  ]})}
  

 bot.setMyCommands([
    {command:"/start",description:"Boshlash"},
    {command:"/info",description:"Ismingiz"},
    {command:"/play",description:"Play Game"}
 ])
 const startGame = async (chatId) => {
    let randomNumber =Math.floor(Math.random()*10);
   chats[chatId]=randomNumber;
   return  bot.sendMessage(chatId,`0 dan 9 gacha son o'yladim. Uni top`,gameOptions)
 }

const start = ()=> {

    
    bot.on("message", msg => {
    const text = msg.text
    const chatId = msg.chat.id
    if ( text ==="/start")
    { return bot.sendMessage(chatId,`Salom "TOPSON" botiga xush keibsiz /play ni bosib o'yin o'ynashingiz munkin`)}
    
    else if ( text ==="/info"){
    return bot.sendMessage(chatId , `Ismingiz: ${msg.from.first_name}`)}

     else if ( text ==="/play"){
  
return startGame(chatId)
}        

    else{return bot.sendMessage(chatId , `Men bu narsani bilmayman`)}                                  
     
    })
    bot.on ( 'callback_query', msg => {
        const data = msg.data
        const chatId = msg.message.chat.id
        if(data ==='/restart')
        {
         return   startGame(chatId)
        }
        if(data==chats[chatId]){
            return bot.sendMessage(chatId, `Tabriklayman,siz to'g'ri topdingiz Javob:${chats[chatId]}`,restartOptions)
        }
        else{
            return bot.sendMessage(chatId, `Men ${chats[chatId]} ni o'ylagan edim , Sizning javobingiz:${data}`,restartOptions)
        }
        
    })
}
start()
